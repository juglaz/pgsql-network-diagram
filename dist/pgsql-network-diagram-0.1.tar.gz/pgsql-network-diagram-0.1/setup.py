from setuptools import setup

setup(
    name='pgsql-network-diagram',    # This is the name of your PyPI-package.
    version='0.1',                          # Update the version number for new releases
    scripts=['sql_pipeline_diagram']                  # The name of your scipt, and also the command you'll be using for calling it
)